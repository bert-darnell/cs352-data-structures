/* Contestant.java:  
 * This class extends Person while adding attributes and methods
 * related to recording performance in the specified contest. 
 *     
 * Author: Name and Student ID
 * Last updated: 
 */
public class Contestant extends Person {
	// A Contestant IS-A Person
	// that also needs needs to keep track of data related to the game
	// Start simple to get your program running, then add attributes and methods as you need them
	
	// Step 1 Add at least one constructor so the driver will compile and run
	
	
	// Step 5 Add attributes and methods to assist with recording game statistics
}
