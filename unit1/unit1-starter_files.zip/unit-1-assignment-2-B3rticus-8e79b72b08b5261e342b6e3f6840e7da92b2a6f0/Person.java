/* Person.java:  
 * This class provides a basic object to extend in future labs. 
 * Comments are omitted for accessor and mutator methods    
 * Author: John Cigas
 * Last updated: July 2021
 */

public class Person {

	private String name;
	private int age;
	
	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + "]";
	}
}
