/**
 * @author John Cigas
 *
 * Stores low and high temperature data for a city/state 
 */
public class Temperature {
	private String myName = "John";

	
	/* Add appropriate instance attributes, constructors, and accessor/mutator methods */
}
