
public class BlahBlah {

	public static void main(String[] args) {
		System.out.println("Blah Blah Blah, Ginger");

	}

}
